import {Component, OnInit} from '@angular/core';
// import {UiService} from './services/ui/ui.service.ts';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})

export class HomeComponent implements OnInit {
  showMenu = false;
  darkModeActive: boolean;

  // constructor(public ui: UiService) {

  // }

  ngOnInit() {
    // this.ui.darkModeState.subscribe((value) => {
    //   this.darkModeActive = value;
    // });
  }

  toggleMenu() {
    this.showMenu = !this.showMenu;
  }

  // modeToggleSwitch() {
  //   this.ui.darkModeState.next(!this.darkModeActive);
  // }
}
