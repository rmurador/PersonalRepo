import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { DataService } from '../service/data.service';
import 'jquery';
import { TableService } from '../service/table/table.service';
import { DomSanitizer } from '@angular/platform-browser';
import { Observable } from 'rxjs';


@Component({
  selector: 'app-scripts',
  templateUrl: './scripts.component.html',
  styleUrls: ['./scripts.component.css']
})
export class ScriptsComponent implements OnInit {

  scname = '';
  los = '';
  selected;
  scripts;
  custparams;
  showSpinner = true;
  showModSpinner = false;
  outputkeys = [];
  outputvalues = [];
  showJSON = false;
  fileURL;

  @Output() $updateScriptHistory = new EventEmitter<any>();
  http: any;
  apiEndPoint: any;

  constructor(private dataService: DataService, private tableService: TableService) { }

  ngOnInit() {
    // Gets List of Scripts
    this.dataService.getScripts().subscribe(res => {
      this.showSpinner = false;
      this.scripts = res;
    });

    this.tableService.currentMessage.subscribe(message => {
      this.selected = message;
    });

  }

  // run scripts based on the selected nodes
  public runScript(scForm) {
    // Clears previous output
    this.outputkeys = [];
    this.outputvalues = [];
    $('#durationp').text('');
    // opens modal and shows spinner
    ($('#datamod') as any).modal('show');
    this.showModSpinner = true;
    const ctls = scForm.form.controls;
    // form data object to be sent in request body
    const fdata = {
      scname: ctls.scname.value,
      los: this.selected,
      cparams: this.custparams
    };

    // makes post request to API to run selected script on selected servers with optional parameters
    this.dataService.runScript(fdata).subscribe(r => {
      // console.log('script result: ', r);
      this.showModSpinner = false;
      this.outputkeys = Object.keys((r as any).out[0]);
      this.outputvalues = (r as any).out;
      $('#datap').text('Raw JSON: ' + JSON.stringify(r));
      $('#durationp').text('Duration: ' + JSON.stringify((r as any).elapsed) + ' ms');
      // Update Script History Componenet
      this.$updateScriptHistory.emit();
    });

  }

  // downloads selected script
  downloadScript() {
    // gets script name from checked radio button
    const scname = $('input[name="scname"]:checked')[0].attributes[4].value;
    // clicks invisible a tag that matches that script name to download it
    $(`#${scname}_dl_link`).click();
  }

  // (wip) allows you to upload scripts to the server
  uploadScript(files: FileList) {
    console.log(files);
    this.dataService.uploadScript(files).subscribe(r => {
      console.log(r);
    });
  }

  // (wip) allows you to view the file contents of the selected script
  viewScript() {

  }

  // show/hide raw json output from script
  toggleRawJSON() {
    this.showJSON = !this.showJSON;
    $('#datap').prop('style', 'display: ' + (this.showJSON ? 'block' : 'none') + ';');
  }

}
