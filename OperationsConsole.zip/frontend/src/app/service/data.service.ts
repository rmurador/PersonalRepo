import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpEventType, HttpResponse } from '@angular/common/http';


@Injectable()
export class DataService {

  // IP and port of the Backend API
  baseUrl = 'http://10.254.243.68:8077';

  constructor(private http: HttpClient) {
    this.getScripts();
  }
  /* json format must use:
    vtmPoolName
    vtmNodesInPool_A
    vtmNodesInPool_B
  */
  public getBucket() {
    return this.http.get('https://s3-us-west-2.amazonaws.com/ocprototypebucket/pools.json');
  }
  
  public getData(link: any) {
    return this.http.get(this.baseUrl + '/' + link);
  }

  // pools meant for testing web application
  public getPoolsTest() {
    return this.http.get(this.baseUrl + '/test/testpool2');
  }

  // Pulls a list of scripts to be run for the application
  public getScripts() {
    return this.http.get(this.baseUrl + '/scripts');
  }

  // Pulls script histroy from database
  public getScriptHistory() {
    return this.http.get<Array<any>>(this.baseUrl + '/scriptlogs');
  }

  // Pulls script histroy details from database
  public getScriptDetails(logid) {
    return this.http.get(this.baseUrl + '/scriptlogs/' + logid);
  }

  // Sends data for running scripts
  public runScript(fdata) {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    };
    return this.http.post(this.baseUrl + '/run/ps', fdata, httpOptions);
  }

  // Not implemented due to files being uploaded as byte arrays
  public uploadScript(files) {
    if (files.length > 0) {
        // console.log(files['0']);
        // const formData: FormData = new FormData();
        // formData.append('file', files['0'], files['0'].name);
        const fdata = {
          file: 'mmkay'
        };
        const httpOptions = {
          headers: new HttpHeaders({
            'Content-Type': 'text/plain'
          })
        };
        console.log(files.get);
        return this.http.post(`${this.baseUrl}/scripts`, fdata, httpOptions);
    }
  }
}
