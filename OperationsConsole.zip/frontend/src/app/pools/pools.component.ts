import { Component, OnInit, AfterViewChecked, PipeTransform, Pipe } from '@angular/core';
import { DataService } from '../service/data.service';
import { TableService } from '../service/table/table.service';
import { BrowserModule, DomSanitizer } from '@angular/platform-browser';

@Pipe({
  name: 'highlight'
})
export class HighlightSearch implements PipeTransform {
  constructor(private sanitizer: DomSanitizer) { }
  // value is the variable on the left side of the pipe
  // args is the variable on the right side of the pipe after highlight:
  transform(value: any, args: any) {

    // returns the original value
    if (!args) {
      return value;
    }
    // re sets regex - insensitive case
    const re = new RegExp(args, 'gi');
    // match - sets the array to the matched results
    const match = (String)(value).match(re);

    // If there's no match, just return the original value.
    if (!match) {
      return value;
    }
    // replacedValue sets the matched text to be wrapped with mark tag for highlighting
    const replacedValue = (String)(value).replace(re, '<mark class="mark" style="background-color: #2AA48C;">' + match[0] + '</mark>');

    // returns a sanitized version of replacedValue
    return this.sanitizer.bypassSecurityTrustHtml(replacedValue);
  }
}

@Component({
  selector: 'app-pools',
  templateUrl: './pools.component.html',
  styleUrls: ['./pools.component.css'],
  providers: [DataService, HighlightSearch]
})

export class PoolsComponent implements OnInit {
  // contains json data to be displayed on html component
  pools: any;
  showSpinner = true;
  // array that contains node values to be passed into scripts component
  passed: string[] = [];
  // searchTerm updated by input event of the searchbar - used for the highlight pipe
  searchTerm: string;

  constructor(private dataService: DataService, private tableService: TableService) { }

  ngOnInit() {

    // Subscribes service to update pools
    this.dataService.getData('devpools').subscribe(data => {
      // this.dataService.getBucket().subscribe(data => {
      this.pools = data;
    });

    // Subscribes service to update scripts component
    this.tableService.currentMessage.subscribe(message => {
      this.passed = message;
    });
  }
  /*
    search function iterates through table rows.
    on each row, seach iterates through the nodes (<p>)
    changing the display based on the if the text matches
    the searched term (filter).
  */
  search(e) {
    let filter;
    let table;
    let tr;
    let txtValue;
    let input;
    this.searchTerm = e.target.value;
    // check is used to find out whether all nodes of a section were set to visible or not.
    let check;
    let visible = false;
    // count was used to keep track of whether row A and B were visible or not.
    // let count = 0;


    // sets UI elements to variables
    input = document.getElementById('search');
    filter = input.value.toUpperCase();
    table = document.getElementById('PoolTable');
    tr = table.getElementsByTagName('tr');

    // loops through table on the data cells 0 and 2 (PoolName and Node)
    for (let i = 2; i < tr.length; i++) {
      // sets count to 0 if we are on a new Pool.
      // (tr[i].cells[0].id === '') ? count = count : count = 0;

      check = 0;

      /*
        For loop iterates through the <p> in the table row. We check to see if the text of the <p>
        matches the searched text.
        If the <p> does not match then we change the display of the <p> to none.
        Otherwise we ensure that the display is set to '' (visible).
      */
      const p = ((tr[i].cells[2]).hasChildNodes()) ? (tr[i].cells[2]).getElementsByTagName('p') : '';

      // tslint:disable-next-line:prefer-for-of
      for (let x = 0; x < p.length; x++) {

        txtValue = p[x].textContent || p[x].innerText;

        // Checks for match and sets visibility accordingly.
        if (txtValue.toUpperCase().indexOf(filter) > -1) {
          p[x].style.display = '';
        } else {
          p[x].style.display = 'none';
          check++;
        }

        visible = (check < p.length) ? true : false;
        // Sets entire row visiblity if all nodes (<p>) have been set to not visible.
        if (visible) {
          tr[i].style.display = '';
        } else {
          tr[i].style.display = 'none';
          // count++;
        }
      }

      /*
      This check was meant to change the display of the Pool to none.
      However, something is broken. When refrencing the Pool row (-2),
      the display of changed rows are not visibly correct.

      if (count > 1 || count > 1 && i === 3) {

        tr[i - 1].style.display = 'none';

      } else if (count < 1) {

        tr[i - 1].style.display = '';

      }
      */
    }
  }

  selectNode(pool: any, node: string, zone: string) {

    // Array of HTMLObjects
    const checkboxes = document.getElementsByClassName(pool.vtmPoolName);

    // Sets where to start in the checkboxes array based on the zone
    const zoneAInt = this.getZoneInt(checkboxes, 'a');
    const zoneBInt = this.getZoneInt(checkboxes, 'b');

    const zoneInt = (zone === 'a') ? zoneAInt : zoneBInt;
    // Checks if the node is in the passed array
    if (this.passed.includes(node)) {

      // removes node from array
      // the '1' is how many objects to remove
      this.passed.splice(this.passed.indexOf(node), 1);

      // sets the pool checkbox to false
      (checkboxes[0] as HTMLInputElement).checked = false;

      // sets zone to false depending on which node was selected
      if ('a' === zone) {
        (checkboxes[zoneAInt] as HTMLInputElement).checked = false;
      } else {
        (checkboxes[zoneBInt] as HTMLInputElement).checked = false;
      }

    } else {

      // If the node is not in the array it is added to the array
      this.passed.push(node);

      let allNodesChecked = true;

      // Loops through all nodes - starting at 3 to skip zones and pool
      for (let i = zoneInt + 1; i < checkboxes.length; i++) {

        // checks to see if node is in the same zone we are working in and checks if the node checkbox is set to false
        if ((checkboxes[i] as HTMLInputElement).id === zone && (checkboxes[i] as HTMLInputElement).checked.valueOf() === false) {
          allNodesChecked = false;
        }
      }

      if (allNodesChecked) {

        (checkboxes[zoneInt] as HTMLInputElement).checked = true;

        // checks the zone then checks the pool
        if ((checkboxes[zoneBInt] as HTMLInputElement).checked.valueOf() === (checkboxes[zoneAInt] as HTMLInputElement).checked.valueOf()) {
          (checkboxes[0] as HTMLInputElement).checked = true;
        }

      }
    }
    // updates the service
    this.tableService.changeMessage(this.passed);
    console.log(this.passed);
  }

  // pool is json data - zone is which zone it is in
  selectZone(pool: any, zone: string) {

    // Array of HTMLObjects
    const checkboxes = document.getElementsByClassName(pool.vtmPoolName);

    // Sets where to start in the checkboxes array based on the zone
    const zoneAInt = this.getZoneInt(checkboxes, 'a');
    const zoneBInt = this.getZoneInt(checkboxes, 'b');

    const zoneInt = (zone === 'a') ? zoneAInt : zoneBInt;

    for (let i = zoneInt + 1; i < checkboxes.length; i++) {

      // checks to see if node is in the same zone we are working in and checks if the node checkbox is set to false
      if ((checkboxes[i] as HTMLInputElement).id === zone) {
        if ((checkboxes[i] as HTMLInputElement).checked.valueOf() !== (checkboxes[zoneInt] as HTMLInputElement).checked.valueOf()) {
          (checkboxes[i] as HTMLInputElement).click();
        }
      }
    }

  }

  // pool is json data
  selectPool(pool: any) {

    // Array of HTMLObjects
    const checkboxes = document.getElementsByClassName(pool.vtmPoolName);

    const zoneAInt = this.getZoneInt(checkboxes, 'a');
    const zoneBInt = this.getZoneInt(checkboxes, 'b');

    // Boolean value of the Pools checkebox
    const poolChecked = (checkboxes[0] as HTMLInputElement).checked.valueOf();

    if ((checkboxes[zoneAInt] as HTMLInputElement).checked.valueOf() !== poolChecked) {
      (checkboxes[zoneAInt] as HTMLInputElement).click();
    }
    if ((checkboxes[zoneBInt] as HTMLInputElement).checked.valueOf() !== poolChecked) {
      (checkboxes[zoneBInt] as HTMLInputElement).click();
    }

  }

  // Table is changed to be a different Pool
  changeSelectedPool() {
    this.passed = [];
    this.tableService.changeMessage(this.passed);
    // Gets the value of the selector
    const selected = (document.getElementById('selector') as HTMLInputElement).value;
    // Repopulate the table with the selected JSON
    this.dataService.getData(selected).subscribe(data => {
      this.pools = data;
    });
  }

  getZoneInt(checkboxes: any, zone: any): number {
    for (let i = 1; i < checkboxes.length; i++) {
      if ((checkboxes[i] as HTMLInputElement).id === zone) {
        return i;
      }
    }
    return 0;
  }
}

