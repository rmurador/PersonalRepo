import { Component, Input, OnInit } from '@angular/core';
import {UiService} from './service/ui/ui.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent implements OnInit {
  title = 'Operations Console';
  showMenu = false;
  darkModeActive: boolean;

  constructor(public ui: UiService) {

  }

  ngOnInit() {
    this.ui.darkModeState.subscribe((value) => {
      this.darkModeActive = value;
    });
  }

  toggleMenu() {
    this.showMenu = !this.showMenu;
    const imageVisibility = document.getElementById('menu__icon');
    if (this.showMenu) {
      imageVisibility.setAttribute('style', 'z-index: -100');

    } else {
      imageVisibility.setAttribute('style', 'z-index: 100');

    }
  }

  modeToggleSwitch() {
    this.ui.darkModeState.next(!this.darkModeActive);
  }
}
