import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { DataService } from './service/data.service';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';
import { PoolsComponent, HighlightSearch } from './pools/pools.component';
import { ScriptsComponent } from './scripts/scripts.component';
import { HomeComponent } from './pages/home/home.component';
import { LoginComponent } from './pages/login/login.component';
import { SpinnerComponent } from './spinner/spinner.component';
import { ScriptHistoryComponent } from './script-history/script-history.component';
import { UiService } from './service/ui/ui.service';
import { FormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';


@NgModule({
  declarations: [
    AppComponent,
    PoolsComponent,
    ScriptsComponent,
    SpinnerComponent,
    HomeComponent,
    LoginComponent,
    ScriptHistoryComponent,
    HighlightSearch
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    BrowserAnimationsModule,
  ],
  providers: [
    DataService,
    UiService,
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
