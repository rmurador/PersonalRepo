import { Component, OnInit } from '@angular/core';
import { DataService } from '../service/data.service';

@Component({
  selector: 'app-script-history',
  templateUrl: './script-history.component.html',
  styleUrls: ['./script-history.component.css']
})
export class ScriptHistoryComponent implements OnInit {

  scripts;
  showSpinner = true;
  showModSpinner = true;
  outputkeys = [];
  outputvalues = [];
  showJSON = false;

  constructor(private dataService: DataService) { }

  ngOnInit() {
    this.getSchist();
  }

  // fetch script history list from API and update view
  // also gets called automatically when a script is run from the scripts component
  getSchist() {
    this.showSpinner = true;
    this.dataService.getScriptHistory().subscribe(r => {
      // set scripts equal to reversed json response (reversed so that most recent is first instead of last)
      this.scripts = r.reverse();
      this.showSpinner = false;
    });
  }

  // fetch script details from API, then show modal and populate table dynamically with json response data
  getScriptDetails(logid) {
    this.showModSpinner = true;
    // show modal
    ($('#schistmod' + logid) as any).modal('show');
    // fetch script details from API
    this.dataService.getScriptDetails(logid).subscribe(r => {
      this.showModSpinner = false;
      // set output keys for table headers
      this.outputkeys = Object.keys((r as any).Output[0]);
      // set output values for table rows
      this.outputvalues = (r as any).Output;
      // inject raw json into hidden p tag
      $('#datap' + logid).text(JSON.stringify(r));
      // populate script duration p tag
      $('#durationp' + logid).text('Script Duration: ' + (r as any).DurationMS + ' ms');
    });
  }

  // show/hide raw json response
  toggleRawJSON(logid) {
    this.showJSON = !this.showJSON;
    $('#datap' + logid).prop('style', 'display: ' + (this.showJSON ? 'block' : 'none') + ';');
  }

}
