module.exports = class fruit {
    constructor(name, color) {
        this.name = name
        this.color = color
    }
}