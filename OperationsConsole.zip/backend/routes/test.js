// Test endpoints
const express = require('express');
const ele = require('express-list-endpoints');
const testpool = require('../testpool.json');
const testpool2 = require('../refactorTest2Pools.json');
const fruit = require('../models/fruit.js');
const router = express.Router();

router.get('/', (req, res) => {
    res.send(ele(router));
});

router.get('/testpool', (req, res) => {
    res.send(testpool);
});

router.get('/testpool2', (req, res) => {
    res.send(testpool2);
});

router.get('/fruits', (req, res) => {
    let fruits = [new fruit('apple', 'red'), new fruit('orange', 'orange'), new fruit('strawberry', 'red')];
    res.send(fruits);
});


module.exports = router;