//Endpoints for Running PS Scripts
const express = require('express');
const psm = require('node-powershell');
const ele = require('express-list-endpoints');
const ocdb = require('../ocdb.js');
const router = express.Router();
let ps = new psm({executionPolicy: "Unrestricted", noProfile: false});

router.get('/', (req, res) => {
    res.send(ele(router));
});

//Main API Endpoint for running scripts
router.post('/ps', (req, res) => {
    let psname = req.body.scname;
    let los = req.body.los;
    let cparams = req.body.cparams;
    console.log(`${los}`);
    let cmd = `.\\scripts\\${psname}.ps1`;
    if (los) cmd += ` -los '${los}'`;
    if (cparams) cmd += cparams;
    let s = new Date();
    let dt = formatDate(s);
    runps(cmd).then(out => {
        console.log('raw script output: ', out);
        let e = (new Date() - s);
        let r = {
            scname: psname,
            servers: (los.count > 0 ? los : null),
            start: dt,
            elapsed: e,
            out: JSON.parse(out)
        }
        res.send(r);
        ocdb.query(`INSERT INTO OCLogs (ScriptName, Output, Los, StartTime, DurationMS) VALUES(?, ?, ?, ?, ?)`,
                   [r.scname, JSON.stringify(r.out), r.servers, r.start, r.elapsed],
                   (err, rows, fields) => {
            if (err) console.log(err);
        });
    });
});

//Formats date for json
function formatDate(s) {
    var date = s.getFullYear() + '-' + (s.getMonth() + 1) + '-' + s.getDate();
    var time = ((s.getHours() < 10 ? '0':'') + s.getHours()) + ":" + ((s.getMinutes() < 10 ? '0':'') + s.getMinutes()) + ":" + ((s.getSeconds() < 10 ? '0':'') + s.getSeconds());
    return date + ' ' + time;
}

//runs powershell script asynchronously and returns script output
async function runps(path) {
    ps.addCommand(path);
    let out = await ps.invoke()
    .then(output => { return output; })
    .catch(err => console.log(err));
    return out;
}

module.exports = router;