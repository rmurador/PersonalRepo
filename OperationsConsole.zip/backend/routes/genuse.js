//general use endpoints
const express = require('express');
const fs = require('fs');
const fetch = require('node-fetch');
const ele = require('express-list-endpoints');
const ocdb = require('../ocdb.js');
const pools = require('../pools.json');
const devpools = require('../DevPools.json');
const router = express.Router();

router.get('/', (req, res) => {
    res.send(ele(router));
});

router.get('/pools', (req, res) => {
    res.send(pools);
});

router.get('/devpools', (req, res) => {
    res.send(devpools);
});

router.get('/s3pools', (req, res) => {
    fetch('https://s3-us-west-2.amazonaws.com/amds.sot/_AMDS-PoolsSOR/pools.json')
    .then(r => r.json())
    .then(r => res.send(r))
    .catch(err => console.log(err));
});
//Returns the names of all the available scripts to run (without file extensions)
router.get('/scripts', async (req, res) => {
    fs.readdir('./scripts/', (err, files) => {
        res.send(files.map(f => f.substr(0, f.length - 4)));
    });
});
//Dowload Script
router.get('/scripts/:scname', async (req, res) => {
    let scname = req.params.scname;
    res.download(`./scripts/${scname}.ps1`);
});
//View Script
router.get('/scripts/:scname/view', async (req, res) => {
    let scname = req.params.scname;
    fs.readFile(`./scripts/${scname}.ps1`, (err, f) => {
        res.send(JSON.stringify(f));
    });
});
//Upload Script
router.post('/scripts', async (req, res) => {
    console.log('req.body: ', req.body.file);
    let file = req.body.file;
    console.log(file);
    fs.writeFile(`./scripts/${file.name}`, file);
});
//Returns all script logs from DB
router.get('/scriptlogs', (req, res) => {
    ocdb.query(`SELECT LogID, ScriptName, CAST(StartTime AS CHAR) AS StartTime FROM OCLogs;`, [], (err, rows, fields) => {
        if (err) console.log(err);
        res.send(rows);
    });
});
//Returns specific script log from DB
router.get('/scriptlogs/:logid', (req, res) => {
    let logid = parseInt(req.params.logid);
    if (logid) {
        ocdb.query(`SELECT Output, DurationMS FROM OCLogs WHERE LogID = ?;`, [logid], (err, rows, fields) => {
            if (err) console.log(err);
            rows[0].Output = JSON.parse(rows[0].Output);
            res.send(rows[0]);
        });
    } else {
        console.log(`LogID Invalid: ${logid}`);
        res.send(`LogID Invalid: ${logid}`);
    }
});

module.exports = router;