const app = require('express')();
const bparser = require('body-parser');
const cors = require('cors');
const morgan = require('morgan');

const PORT = 8077;

//define routes
let genuse = require('./routes/genuse');
let run = require('./routes/run');
let test = require('./routes/test');

//use middleware
app.use(morgan('dev'));
app.use(cors());
app.use(bparser.json());


//map routes
app.use('/', genuse);
app.use('/run', run);
app.use('/test', test);

//listen
app.listen(PORT, () => {
    console.log(`Listening on port ${PORT}`);
});

module.exports = app;