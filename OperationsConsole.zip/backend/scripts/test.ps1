<#
    .SYNOPSIS
        ##
    .DESCRIPTION
        This script is used for the application that will be displaying pool metrics
    .PARAMETER LOS
        The List of servers to run against.
        Required to run command.
    .EXAMPLE
        ./ScriptName.ps1 -LOS <FilePath To SoT Json>
    .NOTES
        This version includes credential checking
    .FUNCTIONALITY
        PowerShell Language
    #>

#[CmdletBinding()] 
#param(
 #   [Parameter( Position = 0,
  #      Mandatory = $true,
   #     ValueFromPipeline = $true )]
    #[string[]]$LOS,
    # SoT path must be first, it must be a path to one and it bust be added
    
    #[Parameter( Mandatory = $false)]
    #[pscustomobject[]]$CredentialArray
#)

return 'data123' | ConvertTo-Json