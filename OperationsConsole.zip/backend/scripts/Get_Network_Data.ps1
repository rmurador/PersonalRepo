<#
DESCRIPTION
Get Net data gets the minimum, maximum, and average of the network traffic coming in and out
of an instance during the last two hours.
The Data is counted as Bytes.

#>

[CmdletBinding()]
param(
  $LOS
)
<#
PARAMETER $LOS
   $LOS is a required parameter for the scripts to work with this application
   It must be a String Array and
   It also must be position 0 and madatory
#>
if([string]::IsNullOrEmpty($LOS)){
    return "Script failed to execute: No servers specified"
}

$output = @()


function get-node-dist (){
  
    $o = ""
    $subnets = Get-EC2Subnet
    $instances = (Get-EC2Instance).Instances
    foreach ($i in $instances)
    {
        $iName = ($i.tags | Where-Object -Property key -EQ 'Name').Value
        $iInstanceId = $i.instanceID
        $iSubnetID = $i.SubnetID
        $iAZ = ($subnets | Where-Object -Property subnetid -EQ $isubnetID).AvailabilityZone
 
        $o = New-Object -TypeName System.Management.Automation.PSObject -Property ([ordered]@{
                'Instance Name' = $iName;
                'InstanceID'    = $iInstanceId;
                'Subnet'        = $iSubnetID;
                'AZ'            = $iAZ
                'Server'        = $iName
                'WFE'           = ($i.tags | Where-Object -Property key -EQ 'PodName').Value
                'State'         = $i.State.Name
        })
    
        $Script:output += $o
        Write-Debug "Node Dist: $o"
    }
}

#$pools = @("wcwfe", "pmwfe")


function get-ec2-status (){
   
    param(
        $servers, $pmservers
    )
    get-node-dist
    $Results += $output
    $Script:output = @()
    $DataObj = [Ordered]@{
        ID = ''
        Name =''
        DataInAvg = '0'
        DataOutAvg = '0'
	    DataInMin = '0'
        DataOutMin = '0'
	    DataInMax = '0'
        DataOutMax = '0'
    }
	$Dimension = New-Object Amazon.CloudWatch.Model.Dimension
	$Dimension.Name = 'InstanceID'
	$date = Get-Date
	foreach($server in $servers)
    {
        foreach($result in $Results)
        {
            if($result.Server -eq $server)
            { 
                    $Dimension.Value = $result.state
                    $Stats = new-object psobject -Property $DataObj
					$Stats.Name = $result.server
                    $Stats.ID = $result.InstanceID
                    
					#Get metric data from the instances
					$DataIn = (Get-CWMetricStatistic -MetricName NetworkIn -Namespace AWS/EC2 -Dimension @{Name = "InstanceId"; Value =  $Stats.ID} -Statistics Maximum, Average, Minimum -Period 600 -UtcStartTime ($date).AddMinutes(-30) -UtcEndTime ($date)).Datapoints
                    $DataOut = (Get-CWMetricStatistic -MetricName NetworkOut -Namespace AWS/EC2 -Dimension @{Name = "InstanceId"; Value = $Stats.ID} -Statistics Maximum, Average, Minimum -Period 600 -UtcStartTime ($date).AddMinutes(-30) -UtcEndTime ($date)).Datapoints
			        
                    #if there is data gathered, reverse the list of the datapoints so they are chronological place it in the active list
                    if ($DataIn.Maximum.Count + $DataOut.Maximum.Count -gt 0) {
							[array]::Reverse($DataIn.Average)
							[array]::Reverse($DataOut.Average)
							[array]::Reverse($DataIn.Minimum)
							[array]::Reverse($DataOut.Minimum)
							[array]::Reverse($DataIn.Maximum)
							[array]::Reverse($DataOut.Maximum)
                            Write-Debug "Data reversed in order to be chronological"

                    <# Had to find  away to make the data sets mmore reable since they were going to be mulitple in a single data cell#>
                        for($i = 0; $i -le ($DataIn.Maximum.Count - 1) ; $i++){
                           $divider = ','
                           if($i -eq ($DataIn.Maximum.Count - 1)){
                                $divider = ''
                           }
                            $Stats.DataInAvg  += ($DataIn.Average[$i] ).ToString()+$divider
                            $Stats.DataOutAvg += ($DataOut.Average[$i]).ToString()+$divider
                            $Stats.DataInMin  += ($DataIn.Minimum[$i] ).ToString()+$divider
                            $Stats.DataOutMin += ($DataOut.Minimum[$i]).ToString()+$divider
                            $Stats.DataInMax  += ($DataIn.Maximum[$i] ).ToString()+$divider
                            $Stats.DataOutMax += ($DataOut.Maximum[$i]).ToString()+$divider
                            Write-Debug "Data sorted through and made into string"
                        }
                     <#--------------------------------------------#>
			         }


                    $Script:output += $Stats
            }
        }
    }

}

Try{
$servers = $LOS.Split(",")
Write-Debug "Servers: $servers"
get-ec2-status -servers $servers 'wcwfe'

return ConvertTo-Json -InputObject ($Script:output)
}catch{
     $ErrorMessage = $_.Exception.Message
     return "Script failed to execute: $ErrorMessage"
}