﻿<#
DESCRIPTION
Get CPU data gets the minimum, maximum, and average of the CPU utlization of an instance during the last two hours.
The Data is counted as percentages.

#>


[CmdletBinding()]
param(
  $LOS
)
<#
PARAMETER $LOS
   $LOS is a required parameter for the scripts to work with this application
   It must be a String Array and
   It also must be position 0 and madatory
#>
if([string]::IsNullOrEmpty($LOS)){
    return "Script failed to execute: No servers specified"
}

$output = @()


function get-node-dist (){
  
    $o = ""
    $subnets = Get-EC2Subnet
    $instances = (Get-EC2Instance).Instances
    foreach ($i in $instances)
    {
        $iName = ($i.tags | Where-Object -Property key -EQ 'Name').Value
        $iInstanceId = $i.instanceID
        $iSubnetID = $i.SubnetID
        $iAZ = ($subnets | Where-Object -Property subnetid -EQ $isubnetID).AvailabilityZone
 
        $o = New-Object -TypeName System.Management.Automation.PSObject -Property ([ordered]@{
                'Instance Name' = $iName;
                'InstanceID'    = $iInstanceId;
                'Subnet'        = $iSubnetID;
                'AZ'            = $iAZ
                'Server'        = $iName
                'WFE'           = ($i.tags | Where-Object -Property key -EQ 'PodName').Value
                'State'         = $i.State.Name
        })
    
        $Script:output += $o
        Write-Debug "Node Dist: $o"
    }
}

#$pools = @("wcwfe", "pmwfe")



function get-ec2-status (){
   
    param(
        $servers, $pmservers
    )
    get-node-dist 
    $Results +=  $Script:output
    $Script:output = @()
    #Create object to store data in
    $DataObj = @{ 
        ID = ''
        Name =''
        DataMax = ''
        DataMin = ''
	    DataAvg = ''
	    TimeStamp = ''
        SampleCount = ''
	    Sum = ''
}
	$Dimension = New-Object Amazon.CloudWatch.Model.Dimension
	$Dimension.Name = 'InstanceID'
	$date = Get-Date
	foreach($server in $servers)
    {
        foreach($result in $Results)
        {
            if($result.Server -eq $server)
            { 
 				$Stats = new-object psobject -Property $DataObj
				$Stats.Name = $result.server
                $Stats.ID = $result.InstanceID
				$date = get-date 
                
                #Get data points from the last two hours from the instance
				$CPUstats = (Get-CWMetricStatistic -MetricName CPUUtilization -Namespace AWS/EC2 -Dimension @{Name = "InstanceId"; Value = $result.InstanceID} -Statistics Maximum, Average, Minimum -Period 3600 -UtcStartTime ($date).AddSeconds(-3600) -UtcEndTime ($date)).Datapoints

				$Stats.DataMax = $CPUstats.Maximum
				$Stats.DataMin = $CPUstats.Minimum

                #If the time stamps are not null, make them into a readable format, else, leave it be    
                If($CPUstats.TimeStamp -eq -not $null){$Stats.TimeStamp = ($CPUstats.TimeStamp).ToString()}else{$Stats.TimeStamp = ($CPUstats.TimeStamp)}

				$Stats.SampleCount = $CPUstats.SampleCount
				$Stats.Sum = $CPUstats.Sum
				$Stats.DataAvg = $CPUstats.Average
                
                $Script:output += $Stats
                Write-Debug "$result.InstanceID : Ran through the script"
            }
        }
    }

}

try{

$servers = $LOS.Split(",")
Write-Debug "Servers: $servers"
get-ec2-status -servers $servers 'wcwfe'

return ConvertTo-Json -InputObject $Script:output
}catch{    
     $ErrorMessage = $_.Exception.Message
     return "Script failed to execute: $ErrorMessage"}