﻿<#
DESCRIPTION
Get Name and state returns the operating condition, name, and ID of all the servers.

#>
[CmdletBinding()]
param($LOS = '')
try{

$instances = (Get-EC2Instance).Instances
$list = @()
#Defines an object  to store the information
$props = @{
Name = ''
ID = ''
State = ''
}
$tagcounter = 0 #Debug tool

ForEach ($inst in $instances){
    
    $tags = $inst.tags
    $instanceid = $inst.InstanceId
    $foundname = 0

    if(-Not ($foundname)){ #Look through the tags for a name Key, if not found in the loop, go to the next if.
        ForEach($tag in $tags){
            if($tag.Key -eq 'name'){
                $Pop = new-object psobject -Property $props
                $Pop.Name = $tag.Value
                $Pop.ID = $inst.InstanceId
                $Pop.State = $inst.state.name.Value
                $list += $Pop
                $foundname = 1
                Write-Debug "Found name for $Pop.ID and its $Pop.Name"
            }
        }
    }
    if(-Not $foundname){ #Since no name was found, make a new object with a blank name and its details
        $Pop = new-object psobject -Property $props
        $Pop.Name = "     "
        $Pop.ID = $inst.InstanceId
        $Pop.State = $inst.state.name.Value
        Write-Debug "NAME NOT FOUND FOR $Pop.ID"
        $list += $Pop
    }
}



return ConvertTo-Json -InputObject $list

}catch{
     $ErrorMessage = $_.Exception.Message
     return "Script failed to execute: $ErrorMessage"
}