﻿<#
DESCRIPTION
Basic search of tags, you can either enter 
- a key that you're looking for
- A value that you're looking for
- or both.

#>

 param (
    $LOS ='',
    $Key,
    $Value
 )
try{
$instances = (Get-EC2Instance).instances
$KeyEmpty = [string]::IsNullOrEmpty($Key)
$ValueEmpty = [string]::IsNullOrEmpty($Value)


$list = @{}
#Defines an object  to store the information
$props = [Ordered]@{
Name = ''
ID = ''
Key = ''
Value = ''
}

ForEach ($inst in $instances){
    
    $tags = $inst.tags
    $instanceid = $inst.InstanceId
    $Pop = new-object psobject -Property $props
    
	 
     if(-Not ($KeyEmpty) -and -not ($ValueEmpty)){ #If there is a key and value argument
        ForEach($tag in $tags){
            if(($tag.Key -eq $Key) -and ($tag.Value -eq $Value) ){ #look through tags for the key and value pair
                $Pop.ID = $inst.InstanceId
                $Pop.Key = $tag.Key
                $Pop.Value = $tag.Value
                $foundname = 1
            }
            if($tag.Key -eq 'name'){
                $Pop.Name = $tag.Value
            }

        }
     }elseif(-Not ($KeyEmpty)){ #If there is only a key

        ForEach($tag in $tags){
            if($tag.Key -eq $Key){ #looks through tags for the key
                $Pop = new-object psobject -Property $props
                $Pop.ID = $inst.InstanceId
                $Pop.Key = $tag.Key
                $Pop.Value = $tag.Value
            }
            if($tag.Key -eq 'name'){
                $Pop.Name = $tag.Value
            }
        }
     }elseif(-Not ($ValueEmpty)){ #If there is only a value

        ForEach($tag in $tags){ #looks through tags for the value
            if($tag.Value -eq $Value){
                $Pop = new-object psobject -Property $props
                $Pop.ID = $inst.InstanceId
                $Pop.Key = $tag.Key
                $Pop.Value = $tag.Value
            }
            if($tag.Key -eq 'name'){
                $Pop.Name = $tag.Value
            }
        }
     }else{
       "No search arguments found" #If there isn't a key or value
       break
       }

    if(-not [string]::IsNullOrEmpty($Pop.Key)){$list[$inst.InstanceId] = $Pop}
    }

    $list.Values | ConvertTo-Json
}catch{
     $ErrorMessage = $_.Exception.Message
     return "Script failed to execute: $ErrorMessage"
}