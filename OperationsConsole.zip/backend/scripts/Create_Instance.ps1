﻿<#
DESCRIPTION
Create an Ec2 instance, there are default paramenters for quick deployment.
These Parameters can be seen in the Param().
#>
[CmdletBinding()]
param (
    $LOS ='',
    $ImageId ='ami-061392db613a6357b',
    $PublicIp = $False,
    $InstanceType = 't2.micro',
    $SubnetId = 'subnet-98f26de1',
    $KeyName = 'ep-test',
    $Name = 'MachineByOperationsConsole '+ (Get-Date -Format g)
 )

$params = @{
    ImageId = $ImageId
    AssociatePublicIp = $AssociatePublicIp
    InstanceType = $InstanceType
    SubnetId = $SubnetId
    KeyName = $KeyName
}

$DataObj = @{
        ID = ''
        Name =''
        Action =''
}

$output = @()

try{

    Write-Debug "Parameters passed in
                ImageID : $ImageId
                PublicIp : $PublicIp
                InstanceType : $InstanceType
                SubnetID : $SubnetId
                KeyName : $KeyName
                Name : $Name
                "

    $valuesObj = new-object psobject -Property $DataObj
    $Tags = @( @{key="CreatedBy";value="Powershell"}, @{key="Name";value="$Name"} ) #Create tag array with key value objects

    $NewInstanceResponse = New-EC2Instance @params #Create machine

    $Instances = ($NewInstanceResponse.Instances).InstanceId  #get instance ID from newly created machine

    New-EC2Tag -ResourceId $Instances -Tags $Tags #Change Tags

    <# List Name and ID along with the action for log #>

    $valuesObj.ID = $Instances
    $valuesObj.Name = $Name
    $valuesObj.Action = 'Created'
    Write-Debug "ValuesObj: $valuesObj"

    $output += $valuesObj

    <#-----------------------------------#>
    
    edit-EC2InstanceAttribute -InstanceId $Instances -Attribute disableApiTermination -value true |Out-Null #Enable termination protection
    
    return ConvertTo-Json -InputObject $output

}Catch{
     $ErrorMessage = $_.Exception.Message
     return "Script failed to execute: $ErrorMessage"
}

