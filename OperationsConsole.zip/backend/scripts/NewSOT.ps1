﻿<#
DESCRIPTION
NewSOT is a general developer QOL tool, it reaches out to the EC2 account and creates 
a new Source of Truth based on the servers in the EC2 inventory.

Properties are not included.

#>

param ($LOS='')

$instances = (Get-EC2Instance).Instances
$list = @()
$FirstNames = @('Bad','Horrible','Awful','Miserable','Dandy','Great','Happy','Joyful','Sad','Estatic','Depressed')
$LastNames = @('Llama','Goat','Crocodile','Salmon','Eagle','Elephant','Elk','Snake', 'Panda', 'Rhino','Hawk','Rat','Bear')


#Defines an object  to store the information
$props = @{
Name = ''
ID = ''
State = ''
}
$Poolprop = [Ordered]@{
    vtmPoolName = ''
    vtmNodesInPool_A = @()
    vtmNodesInPool_B = @()
}

$tagcounter = 0 #Debug tool

ForEach ($inst in $instances){
    
    $tags = $inst.tags
    $instanceid = $inst.InstanceId
    $foundname = 0
    if(-Not ($foundname)){ #Look through the tags for a name Key, if not found in the loop, go to the next if.
        ForEach($tag in $tags){
            if($tag.Key -eq 'name'){
                $Pop = new-object psobject -Property $props
                $Pop.Name = $tag.Value

                $list += $Pop
                $foundname = 1
            }
        }
    }
}


$Pools = @()

$list = $list| Sort-Object {Get-Random}
$list = $list.Name | select -uniq
$list.Length
$counter = 0

$NumberOfServers = ($list.Count - 1)

$PoolInUse = $False

While($NumberOfServers -ge 0){

    if($PoolInUse -eq $False){
    $Pool = new-object psobject -Property $Poolprop
    $NodeALength = Get-Random -Minimum 1 -Maximum 6
    $NodebLength = Get-Random -Minimum 1 -Maximum 6
    $PoolInUse = $True
    }

    $Pool.vtmPoolName = $FirstNames[(Get-Random -Maximum $FirstNames.Length)] + $LastNames[(Get-Random -Maximum $LastNames.Length)]
    
    for($i =0; $i -cle $NodeALength; $i++){
    $Pool.vtmNodesInPool_A += $list[$NumberOfServers]
    $NumberOfServers--
    if($NumberOfServers -cle 0){break}
    $counter++
    }


    for($i = 0; $i -cle $NodeBLength; $i++){
    $Pool.vtmNodesInPool_B +=$list[$NumberOfServers]
    $NumberOfServers--
    if($NumberOfServers -cle 0){break}
    $counter++
    }
    $PoolInUse = $False
    $Pools += $Pool

}

$counter

Convertto-Json -InputObject $Pools -depth 3