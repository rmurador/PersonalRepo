 <#
DESCRIPTION
Graceful shutdown of an ec2 instance.

#>

[CmdletBinding()]
param(
  $LOS
)
<#
PARAMETER $LOS
   $LOS is a required parameter for the scripts to work with this application
   It must be a String Array and
   It also must be position 0 and madatory
#>
if([string]::IsNullOrEmpty($LOS)){
    return "Script failed to execute: No servers specified"
}

$DataObj = @{
        ID = ''
        Name =''
        Action=''
}
$output = @()

   function get-node-dist (){
  
	#Get information about EC2 instances and make them into an object with the selected information

    $out = @()
    $o = ""
    $subnets = Get-EC2Subnet
    $instances = (Get-EC2Instance).Instances #Get instances from AWS
    #$instances
    foreach ($i in $instances)
    {
        $iName = ($i.tags | Where-Object -Property key -EQ 'Name').Value
        $iInstanceId = $i.instanceID
        $iSubnetID = $i.SubnetID
        $iAZ = ($subnets | Where-Object -Property subnetid -EQ $isubnetID).AvailabilityZone
 
        $o = New-Object -TypeName System.Management.Automation.PSObject -Property ([ordered]@{
                'Instance Name' = $iName;
                'InstanceID'    = $iInstanceId;
                'Subnet'        = $iSubnetID;
                'AZ'            = $iAZ
                'Server'        = $iName
                'WFE'           = ($i.tags | Where-Object -Property key -EQ 'PodName').Value
                'State'         = $i.State.Name
        })
    
        #$o | select WFE, AZ, Server, InstanceID, State

         $Script:output += $o
         Write-Debug "Node Dist: $o"
    }
}

#$pools = @("wcwfe", "pmwfe")


function stop-ec2 (){
   
    param(
        $servers, $pmservers
    )

    foreach($server in $servers) 
    {
        foreach($result in $Results)
        {
            if($result.Server -eq $server) #IF the servername is the same as the one provided from the LOS
            {
				Stop-EC2Instance -InstanceId $result.InstanceID | Out-Null #Start Machine via the AWS
                
                <# List Name and ID along with the action for log #>
                $valuesObj = new-object psobject -Property $DataObj
                $valuesObj.ID = $result.InstanceID
                $valuesObj.Name = $result.Server
                $valuesObj.Action = 'shutdown'
                Write-Debug "$valuesObj.ID / $valuesObj.Name Has been shutdown" 
                $Script:output += $valuesObj
                <#-----------------------------------#>
            }
        }
    }
}

# $Servers is the list of servers from the LOS

try{
#Results var is an array of server objects
$Results = @()
get-node-dist
$Results += $output
#$Results += get-node-dist $pools[1]
$output = @()
$servers = $LOS.Split(",")
Write-Debug "Servers: $Servers"
stop-ec2 -servers $servers 'wcwfe'


return ConvertTo-Json -InputObject $output

 }catch{
     $ErrorMessage = $_.Exception.Message
     return "Script failed to execute: $ErrorMessage"
}