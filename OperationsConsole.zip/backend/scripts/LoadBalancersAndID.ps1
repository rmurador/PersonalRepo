﻿try{

$ELB = Get-ELBLoadBalancer
$instances = (Get-EC2Instance).Instances
$Pair = @{
ELBName = ""
Instances = @()
}
$NameId = @{
Name = ""
ID = ""
}
$list = @()


foreach($Balancer in $ELB){ #Go Through each Balancer

    $ELBObj = new-object psobject -Property $Pair
    $ELBObj.ELBName = $Balancer.LoadBalancerName
            
    Foreach($ID in $Balancer.Instances){ #Each set of ID in each balancer
        $ListofInstances = @()
        ForEach($InstID in $ID.InstanceId){ #For each ID in the Balancer group

            ForEach ($inst in $instances){ #Go through each avaliable instance

                $IDObj = new-object psobject -Property $NameID    
                $tags = $inst.tags
                $instanceid = $inst.InstanceId
                $foundname = 0
  
                if($instanceid -eq $InstID){
                    if(-Not ($foundname)){
                        ForEach($tag in $tags){
                            if($tag.Key -eq 'name'){
                                $IDObj.ID = $instanceid
                                $IDObj.Name = $tag.Value
                                $JsonId = $IDObj 
                                $ListofInstances +=  $JsonId
                                $foundname = 1

                            }
                        }
                    }
                    if(-Not $foundname){
                        $IDObj.Name = "     "
                        $IDObj.ID = $instanceid
                        $JsonId = $IDObj  
                        $ListofInstances +=  $JsonId  
                    }
                    $ELBObj.Instances += $ListofInstances
                }
                
            }
                    
                     
        }
        #$ListofInstances   
    }
    Write-Debug "Test"

    $List += $ELBObj
}

return Convertto-JSON -depth 3 -InputObject $list

}catch{
     $ErrorMessage = $_.Exception.Message
     return "Script failed to execute: $ErrorMessage"
}