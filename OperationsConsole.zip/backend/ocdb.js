const ocdb = require('mysql');
const creds = require('./ocdbcreds.json');

//initiate db conn here and export
const conn = ocdb.createConnection({
    host: creds.ip,
    user: creds.user,
    password: creds.pw,
    database: creds.dbname
});

module.exports = conn;